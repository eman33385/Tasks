var map;
      function initMap() {
        map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: 26.8206, lng: 30.8025},
          zoom: 8
        });
      }
	   $(".i1").click(function(){
    $('.date').toggle(1000)
});
$('.i2').click(function(){
    $('.time').toggle(1000)
})
